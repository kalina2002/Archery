package com.oldenweb.Archery;
import com.oldenweb.Archery.Main;
import com.oldenweb.Archery.FinishListener;

public class InstrumentedActivity extends Main {
	public FinishListener finishListener ;
	public void  setFinishListener(FinishListener finishListener){
		this.finishListener = finishListener;
	}

	@Override
	public void onDestroy() {
		if (this.finishListener !=null){
			finishListener.onActivityFinished();
		}
		super.onDestroy();
	}

}
