package com.oldenweb.Archery.test;
public interface FinishListener {
	    void onActivityFinished();
	        void dumpIntermediateCoverage(String filePath);
}
